@extends('layouts.app')
@section('content')
<div class="row">
    <?php $stdId = array(); ?>
    <div class="col-md-2" style="width: 200px">
        <table>
            @foreach ($results->unique('teacher_id') as $item)
            <tr>                
                <td>{{$item->student_id}} {{$item->student_id}}</td>
                <?php array_push($stdId, $item->student_id)?>
            </tr>
            @endforeach
        </table>    
    </div>

    <div class="col-md-8" style="width: 800px">
        <table border='2'>
            @foreach ($results->unique('student_id') as $item)
            <tr> 
            @foreach ($stdId as $id)
            <td>
                @if($id = $item->student_id && $item->name = "Biology")             
                {{$item->name}}{{($item->mark1 + $item->mark2)/2}}
                
            </td>
            <td>
                @elseif($id = $item->student_id && $item->name = "French Language")             
                {{$item->name}}{{($item->mark1 + $item->mark2)/2}}
                 
            </td>
            <td>
                @elseif($id = $item->student_id && $item->name = "Mathematics")             
                {{$item->name}} {{($item->mark1 + $item->mark2)/2}}
                @endif
            </td>
            @endforeach
            </tr>
            @endforeach

        <?php //var_dump($stdId);?>
        </table>    
    </div>

</div>
@endsection