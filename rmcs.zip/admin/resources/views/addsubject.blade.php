@extends('layouts.layout')
@section('content')
<div class="container" style="padding-top:130px">
  <form action="/registSubject" method="post">
    @csrf
    <h1 class="row justify-content-center">Add Subject</h1><br>

      <div class="row justify-content-center mt-2">
        <div class="form-group col-md-10 mt-2">
          <label for="name">Subject Name</label>
          <input type="text" class="form-control" id="name" name="name" required>
          <span class="text-danger">@error ('name') {{ $message }} @enderror</span>
          </div>
        </div>

      <div class="row justify-content-center mt-2">
        <div class="form-group col-md-10 mt-2" >
          <label for="coef">Subject Coefficient</label>
          <input type="text" class="form-control" id="coef" name="coef" required >
          @error ('coef')<span class="text-danger">{{ $message }}</span> @enderror
        </div>
      </div>
      <div class="row justify-content-center mt-2">
        <div class="form-group col-md-10 mt-2" >
          <label for="coef">Subject Category</label>
          <select class="form-control" id="student_region" name="student_region">
            <option value="" >Chose Category</option>
            <option value="Far North">Arts</option>
            <option value="North">Sciences</option>
            <option value="Adamawa">General</option>
            <option value="East">Technical</option>
          </select>
          @error ('coef')<span class="text-danger">{{ $message }}</span> @enderror
        </div>
      </div>
      <div class="row justify-content-center">
        <div class="form-group col-md-4">
          <button class="btn btn-primary" type="submit">Register Subject</button>
        </div>
      </div>
  </div>

  </form>
     </div>
@endsection
