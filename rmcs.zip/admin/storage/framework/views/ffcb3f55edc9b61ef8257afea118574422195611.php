<?php $__env->startSection('content'); ?>
<?php if(Session::get('user1') == 200): ?>
<form action="viewstudent" method=""> <br><br><br><br>
  <h1 class="row justify-content-center">Subject Info</h1><br>
  <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Subject Name</th>
      <th scope="col">Teacher Name</th>
      <th scope="col">Teacher Contact</th>
      <th scope="col">Coefficient</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($subject->id); ?></th>
      <td><?php echo e($subject->name); ?></td>
      <td><?php echo e($subject->teacher_first_name); ?> <?php echo e($subject->teacher_last_name); ?></td>
      <td><a href="https://wa.me/237<?php echo e($subject->teacher_phone); ?>"><?php echo e($subject->teacher_phone); ?></a></td>
      <td><?php echo e($subject->coefficient); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?><br><br><br><br>
    <h2>My Subjects</h2>
    <table class="table">
    <thead class="thead-dark">
      <tr>
        <th scope="col">#</th>
        <th scope="col">Subject Name</th>
        <th scope="col">Coefficient</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::get('userid') == $subject->teacher_id): ?>
        <tr>
          <th scope="row"><?php echo e($subject->id); ?></th>
          <td><?php echo e($subject->name); ?></td>
          <td><?php echo e($subject->coefficient); ?></td>s
        </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u723042533/domains/infocam.blog/public_html/rmcs/admin/resources/views/viewsubjects.blade.php ENDPATH**/ ?>