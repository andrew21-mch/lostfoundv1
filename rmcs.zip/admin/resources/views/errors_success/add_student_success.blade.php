<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
      <meta charset="UTF-8">
      <!--<title> Responsiive Admin Dashboard |!-->
      <link rel="stylesheet" href="{{URL::asset('css/admin.css')}}">
      <!-- Boxicons CDN Link -->
      <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
      <script src="https://code.iconify.design/2/2.0.3/iconify.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.1/dist/chart.min.js"></script>

      <link rel="stylesheet" href="{{URL::asset('css/report.css')}}">
      <link rel="stylesheet" href="{{URL::asset('css/bootstrap.min.css')}}">

       <meta name="viewport" content="width=device-width, initial-scale=1.0">
     </head>
  <body><br><br>
    <div class="container" style="font-size:10px">
      <div class="row justify-content-center col-md-12">
        <div class="alert alert-primary mt-4" role="alert" style="text-align:center">
          <h1>Student Was Successfully added</h1>
        </div>
      </div>
      </div>
  </body>
</html>
