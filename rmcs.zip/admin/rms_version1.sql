-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 19, 2021 at 01:04 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `RPRT`
--

-- --------------------------------------------------------

--
-- Table structure for table `Averages`
--

CREATE TABLE `Averages` (
  `student_id` int(11) DEFAULT NULL,
  `student_average` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rms-admins`
--

CREATE TABLE `rms-admins` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rms_averages`
--

CREATE TABLE `rms_averages` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT 0,
  `student_average` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rms_classes`
--

CREATE TABLE `rms_classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_classes`
--

INSERT INTO `rms_classes` (`id`, `class_name`, `teacher_id`) VALUES
(1, 'Form1', NULL),
(2, 'Form2', NULL),
(3, 'Form3', NULL),
(4, 'Form4', NULL),
(5, 'Form5', NULL),
(6, 'Lowersixth', NULL),
(7, 'Uppersixth', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rms_logs`
--

CREATE TABLE `rms_logs` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `login_date` date DEFAULT NULL,
  `login_time` time DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_logs`
--

INSERT INTO `rms_logs` (`id`, `teacher_id`, `login_date`, `login_time`, `created_at`, `updated_at`) VALUES
(1, 33, '2021-11-14', '05:48:01', '2021-11-14', '2021-11-14'),
(2, 33, '2021-11-14', '06:09:06', '2021-11-14', '2021-11-14'),
(3, 33, '2021-11-14', '06:22:21', '2021-11-14', '2021-11-14'),
(4, 33, '2021-11-14', '06:23:52', '2021-11-14', '2021-11-14'),
(5, 33, '2021-11-14', '14:18:52', '2021-11-14', '2021-11-14'),
(6, 33, '2021-11-14', '14:19:29', '2021-11-14', '2021-11-14'),
(7, 33, '2021-11-14', '14:23:57', '2021-11-14', '2021-11-14'),
(8, 33, '2021-11-18', '23:42:53', '2021-11-18', '2021-11-18'),
(9, 33, '2021-11-18', '23:55:18', '2021-11-18', '2021-11-18');

-- --------------------------------------------------------

--
-- Table structure for table `rms_options`
--

CREATE TABLE `rms_options` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_options`
--

INSERT INTO `rms_options` (`id`, `name`) VALUES
(10, 'General'),
(11, 'Technical'),
(12, 'Commercial');

-- --------------------------------------------------------

--
-- Table structure for table `rms_results`
--

CREATE TABLE `rms_results` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `sequence_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `mark1` double DEFAULT 0,
  `mark2` double DEFAULT 0,
  `mark3` double DEFAULT 0,
  `mark4` double DEFAULT 0,
  `mark5` double DEFAULT 0,
  `mark6` double DEFAULT 0,
  `academic_year` year(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_results`
--

INSERT INTO `rms_results` (`id`, `student_id`, `class_id`, `subject_id`, `sequence_id`, `teacher_id`, `updated_at`, `created_at`, `mark1`, `mark2`, `mark3`, `mark4`, `mark5`, `mark6`, `academic_year`) VALUES
(221, 29, 1, 19, 1, 37, '2021-11-07 15:29:57', '2021-11-07 15:29:57', 17, 0, 0, 0, 0, 0, 2021),
(222, 29, 1, 12, 1, 33, '2021-11-13 03:54:17', '2021-11-13 03:54:17', 12, 0, 0, 0, 0, 0, 2021),
(223, 30, 1, 12, 1, 33, '2021-11-13 03:56:45', '2021-11-13 03:56:45', 0, 0, 0, 0, 0, 0, 2021),
(224, 35, 1, 12, 1, 33, '2021-11-13 04:24:47', '2021-11-13 04:24:47', 16, 0, 0, 0, 0, 0, 2021),
(225, 37, 1, 12, 1, 33, '2021-11-13 04:24:54', '2021-11-13 04:24:54', 14, 0, 0, 0, 0, 0, 2021),
(226, 34, 2, 12, 1, 33, '2021-11-13 04:25:04', '2021-11-13 04:25:04', 10, 0, 0, 0, 0, 0, 2021),
(227, 31, 4, 12, 1, 33, '2021-11-13 04:25:10', '2021-11-13 04:25:10', 11, 0, 0, 0, 0, 0, 2021),
(228, 32, 6, 12, 1, 33, '2021-11-13 04:25:16', '2021-11-13 04:25:16', 12, 0, 0, 0, 0, 0, 2021),
(229, 33, 6, 12, 1, 33, '2021-11-13 04:25:20', '2021-11-13 04:25:20', 13, 0, 0, 0, 0, 0, 2021),
(230, 36, 6, 12, 1, 33, '2021-11-13 04:25:26', '2021-11-13 04:25:26', 15, 0, 0, 0, 0, 0, 2021);

-- --------------------------------------------------------

--
-- Table structure for table `rms_sequences`
--

CREATE TABLE `rms_sequences` (
  `id` int(11) NOT NULL,
  `sequence_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_sequences`
--

INSERT INTO `rms_sequences` (`id`, `sequence_name`) VALUES
(1, 'First'),
(2, 'Second'),
(3, 'Third'),
(4, 'Fourth'),
(5, 'Fifth'),
(6, 'Sixth');

-- --------------------------------------------------------

--
-- Table structure for table `rms_students`
--

CREATE TABLE `rms_students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `gender` varchar(20) NOT NULL,
  `option_id` int(11) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `place_of_birth` varchar(60) DEFAULT 'Bamenda',
  `fathers_name` varchar(100) DEFAULT NULL,
  `mothers_name` varchar(100) DEFAULT NULL,
  `parents_contact` varchar(100) DEFAULT NULL,
  `Region` varchar(100) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `result_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_students`
--

INSERT INTO `rms_students` (`id`, `first_name`, `last_name`, `class_id`, `gender`, `option_id`, `date_of_birth`, `place_of_birth`, `fathers_name`, `mothers_name`, `parents_contact`, `Region`, `updated_at`, `created_at`, `result_id`) VALUES
(29, 'MEh', 'Idel', 1, 'Male', 1, '2021-10-14', 'kil', 'FIrt', 'lse', 'msi', 'Adamawa', '2021-10-11 06:24:42', '2021-10-11 06:24:42', NULL),
(30, 'Kely', 'tes', 1, 'Female', 1, '2021-10-28', 'test', 'antoher', 'ano', 'afla', 'Far North', '2021-10-11 06:25:55', '2021-10-11 06:25:55', NULL),
(31, 'Masoma', 'Iya', 4, 'Female', 1, '2021-10-14', 'TestDate', 'My mother', 'MyFather', '748393', 'Adamawa', '2021-10-11 11:36:57', '2021-10-11 11:36:57', NULL),
(32, 'Abongwa', 'Bonalais', 6, 'Male', 1, '1996-10-07', 'Bambili', 'Abongwa', 'Abongwa', '67839930', 'North West', '2021-10-18 07:23:32', '2021-10-18 07:23:32', NULL),
(33, 'Nyan', 'Kely', 6, 'Male', 3, '2021-10-06', 'Djottin', 'Dom', 'Allo', '4893492802', 'North West', '2021-10-18 07:25:03', '2021-10-18 07:25:03', NULL),
(34, 'Drew', 'Dalingtin', 2, 'Female', 1, '2021-10-19', 'Ewondo', 'NOnos', 'Tetno', '8439230', 'Adamawa', '2021-10-18 07:25:53', '2021-10-18 07:25:53', NULL),
(35, 'Seli', 'Joseph', 1, 'Female', 1, '2012-10-12', 'Kristaq', 'Risa', 'Rista', '8493232', 'Far North', '2021-10-18 11:43:18', '2021-10-18 11:43:18', NULL),
(36, 'Mbuh', 'Lynn', 6, 'Male', 1, '2002-07-07', 'Ngaoundere', 'Mbu', 'Mbuhh', '8934892', 'Adamawa', '2021-11-07 16:15:49', '2021-11-07 16:15:49', NULL),
(37, 'Tanison', 'Sonia', 1, 'Female', 1, '2002-04-10', 'Nkoh', 'Job', 'John', '1737829', 'North West', '2021-11-10 14:21:13', '2021-11-10 14:21:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rms_subjects`
--

CREATE TABLE `rms_subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `coefficient` int(11) DEFAULT 4,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_subjects`
--

INSERT INTO `rms_subjects` (`id`, `name`, `teacher_id`, `coefficient`, `updated_at`) VALUES
(11, 'Chemistry', 35, 4, '2021-10-11 14:04:57'),
(12, 'Physics', 33, 3, '2021-11-10 13:05:13'),
(15, 'Physical Science', NULL, 2, '2021-10-07 22:02:54'),
(17, 'Biology', NULL, 3, '2021-10-07 22:02:54'),
(18, 'Commerce', NULL, 3, '2021-10-07 22:02:54'),
(19, 'Geography', 37, 3, '2021-11-07 15:29:18'),
(20, 'History', 34, 3, '2021-10-11 13:41:35'),
(21, 'Economic', 36, 3, '2021-10-18 13:51:19');

-- --------------------------------------------------------

--
-- Table structure for table `rms_teachers`
--

CREATE TABLE `rms_teachers` (
  `id` int(11) NOT NULL,
  `teacher_first_name` varchar(100) NOT NULL,
  `teacher_last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `option_id` int(11) DEFAULT NULL,
  `role` int(11) DEFAULT 100,
  `teacher_phone` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rms_teachers`
--

INSERT INTO `rms_teachers` (`id`, `teacher_first_name`, `teacher_last_name`, `email`, `password`, `option_id`, `role`, `teacher_phone`, `subject_id`, `class_id`, `created_at`, `updated_at`) VALUES
(33, 'Nfon', 'Andrew Tatah', 'nfon@gmail.com', '1111111', 10, 200, 677665533, 12, NULL, '2021-10-11 04:04:13', '2021-11-10 13:05:12'),
(34, 'Alouzeh', 'Brandon', 'brandon@gmail.com', 'andy1234', 10, 100, 848934, 20, NULL, '2021-10-11 13:37:28', '2021-10-11 13:41:35'),
(35, 'Mbangse', 'Marcel', 'mark@gmail.com', 'andy1235', 10, 100, 680720381, 11, NULL, '2021-10-11 13:43:57', '2021-10-11 14:04:57'),
(36, 'Donald', 'Tchinda', 'donald@gmail.com', 'donald', 10, 100, 678449332, 21, NULL, '2021-10-18 13:50:46', '2021-10-18 13:51:19'),
(37, 'Elroy', 'Kanye', 'elroyk@gmai.com', '123456', 10, 100, 76488373, 19, NULL, '2021-11-07 15:18:01', '2021-11-07 15:29:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rms-admins`
--
ALTER TABLE `rms-admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rms_averages`
--
ALTER TABLE `rms_averages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `rms_classes`
--
ALTER TABLE `rms_classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `rms_logs`
--
ALTER TABLE `rms_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `rms_options`
--
ALTER TABLE `rms_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rms_results`
--
ALTER TABLE `rms_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rms-results_rms-class` (`class_id`),
  ADD KEY `fk_rms-results_rms-sequence` (`sequence_id`),
  ADD KEY `fk_rms-results_rms-students` (`student_id`),
  ADD KEY `fk_rms-results_rms-subject` (`subject_id`),
  ADD KEY `fk_rms-results_rms-teacher` (`teacher_id`);

--
-- Indexes for table `rms_sequences`
--
ALTER TABLE `rms_sequences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rms_students`
--
ALTER TABLE `rms_students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rms-students_rms-class` (`class_id`);

--
-- Indexes for table `rms_subjects`
--
ALTER TABLE `rms_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rms_subjects_rms_subjects` (`teacher_id`);

--
-- Indexes for table `rms_teachers`
--
ALTER TABLE `rms_teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rms_teachers_rms_options` (`option_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `class_id` (`class_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rms-admins`
--
ALTER TABLE `rms-admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rms_averages`
--
ALTER TABLE `rms_averages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rms_classes`
--
ALTER TABLE `rms_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rms_logs`
--
ALTER TABLE `rms_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rms_options`
--
ALTER TABLE `rms_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `rms_results`
--
ALTER TABLE `rms_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `rms_sequences`
--
ALTER TABLE `rms_sequences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rms_students`
--
ALTER TABLE `rms_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `rms_subjects`
--
ALTER TABLE `rms_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `rms_teachers`
--
ALTER TABLE `rms_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `rms_averages`
--
ALTER TABLE `rms_averages`
  ADD CONSTRAINT `rms_averages_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `rms_students` (`id`);

--
-- Constraints for table `rms_classes`
--
ALTER TABLE `rms_classes`
  ADD CONSTRAINT `rms_classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `rms_teachers` (`id`);

--
-- Constraints for table `rms_logs`
--
ALTER TABLE `rms_logs`
  ADD CONSTRAINT `rms_logs_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `rms_teachers` (`id`);

--
-- Constraints for table `rms_results`
--
ALTER TABLE `rms_results`
  ADD CONSTRAINT `fk_rms-results_rms-class` FOREIGN KEY (`class_id`) REFERENCES `rms_classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rms-results_rms-sequence` FOREIGN KEY (`sequence_id`) REFERENCES `rms_sequences` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rms-results_rms-students` FOREIGN KEY (`student_id`) REFERENCES `rms_students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rms-results_rms-subject` FOREIGN KEY (`subject_id`) REFERENCES `rms_subjects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_rms-results_rms-teacher` FOREIGN KEY (`teacher_id`) REFERENCES `rms_teachers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rms_students`
--
ALTER TABLE `rms_students`
  ADD CONSTRAINT `fk_rms-students_rms-class` FOREIGN KEY (`class_id`) REFERENCES `rms_classes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rms_subjects`
--
ALTER TABLE `rms_subjects`
  ADD CONSTRAINT `fk_rms_subjects_rms_subjects` FOREIGN KEY (`teacher_id`) REFERENCES `rms_teachers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `rms_teachers`
--
ALTER TABLE `rms_teachers`
  ADD CONSTRAINT `fk_rms_teachers_rms_options` FOREIGN KEY (`option_id`) REFERENCES `rms_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rms_teachers_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `rms_subjects` (`id`),
  ADD CONSTRAINT `rms_teachers_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `rms_classes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
