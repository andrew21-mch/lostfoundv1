<?php $__env->startSection('content'); ?>
<div class="container" style="background-image:url('images/cast.jpeg'); background-repeat:no-repeat; background-size: cover;padding:10% 10%; width:100%">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header btn btn-success" style="color:white; background-color:#440be0">Welcome</div>
                <div class="card-header"><?php echo e(__('CAMSI')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row justify-content-center">
                       <center> <div class="col-md-6">
                            <a href="login" class="btn btn-primary" style="width:100px">Login</a>
                        </div></center>
                        <center><div class="col-md-6 justify-content-center">
                            <a href="/register" class="btn btn-primary"style="width:100px">Register</a>
                        </div></center>

                    </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u723042533/domains/infocam.blog/public_html/rmcs/admin/resources/views/home.blade.php ENDPATH**/ ?>