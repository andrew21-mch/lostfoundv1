

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="home-content">
    <div class="overview-boxes">
      <a class="box" href="form1">
        <div class="right-side">
          <div class="box-topic">Form One</div>
          <div class="counters">Total: <?php echo e($count1); ?></div>
          <div class="counters">Girls: <?php echo e($count1g); ?></div>
          <div class="counters">Boys: <?php echo e($count1-$count1g); ?></div>
          <div class="indicator">
          </div>
        </div>
        <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </a>


      <a class="box" href="form2">
        <div class="right-side">
          <div class="box-topic">Form Two</div>
          <div class="counters">Total:<?php echo e($count2); ?></div>
          <div class="counters">Girls: <?php echo e($count2g); ?></div>
          <div class="counters">Boys: <?php echo e($count2-$count2g); ?></div>

          <div class="indicator">


          </div>
        </div>
        <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </a>



      <a class="box" href="form3">
        <div class="right-side">
          <div class="box-topic">Form Three</div>
          <div class="counters">Total: <?php echo e($count3); ?></div>
          <div class="counters">Girls: <?php echo e($count3g); ?></div>
          <div class="counters">Boys: <?php echo e($count3-$count3); ?></div>

          <div class="indicator">


          </div>
        </div>
        <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </a>


      <a class="box" href="form4">
        <div class="right-side">
          <div class="box-topic">Form Four</div>
          <div class="counters">Total: <?php echo e($count4); ?></div>
          <div class="counters">Girls: <?php echo e($count4g); ?></div>
          <div class="counters">Boys: <?php echo e($count4-$count4g); ?></div>
          <div class="indicator">


          </div>
        </div>
      <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </div>
    </a>

    <div class="home-content">
      <div class="overview-boxes">
        <a class="box" href="form5">
          <div class="right-side">
            <div class="box-topic">Form Five</div>
            <div class="counters">Total: <?php echo e($count5); ?></div>
            <div class="counters">Girls: <?php echo e($count5g); ?></div>
            <div class="counters">Boys: <?php echo e($count5-$count5g); ?></div>
            <div class="indicator">


            </div>
          </div>
        <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </a>

      <a class="box" href="lowersixth">
          <div class="right-side">
            <div class="box-topic">LowerSixth</div>
            <div class="counters">Total: <?php echo e($count6); ?></div>
            <div class="counters">Girls: <?php echo e($count6g); ?></div>
            <div class="counters">Boys: <?php echo e($count6-$count6g); ?></div>
            <div class="indicator">


            </div>
          </div>
        <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
      </a>

        <a class="box" href="uppersixth">
          <div class="right-side">
            <div class="box-topic">UpperSixth</div>
            <div class="counters">Total: <?php echo e($count7); ?></div>
            <div class="counters">Girls: <?php echo e($count7g); ?></div>
            <div class="counters">Boys: <?php echo e($count7-$count7g); ?></div>
            <div class="indicator">


            </div>
          </div>
      <span class="iconify" data-icon="icons8:student" style="color: gray;" data-width="50" data-height="50" data-flip="horizontal"></span>
    </a>
    <a class="box" href="student">
      <div class="right-side">
        <div class="box-topic">Total Enrollment</div>
        <div class="counters">Total: <?php echo e($count); ?></div>
        <div class="counters">Girls: <?php echo e($count1g+$count2g+$count3g+$count4g+$count5g+$count6g+$count7g); ?></div>
        <div class="counters">Boys: <?php echo e($count-($count1g+$count2g+$count3g+$count4g+$count5g+$count6g+$count7g)); ?></div>


        <div class="indicator">


        </div>
      </div>
    </div>
  </div>

    </a>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u723042533/domains/infocam.blog/public_html/rmcs/admin/resources/views/admin_dashboard.blade.php ENDPATH**/ ?>