@extends('layouts.layout')
@section('content')
<div class="container">
<form class="form" action="index.html" method="post">


  <div class="class">
    <br><br><br><br>
    <table id="customers">
      <h2>Form 1</h2>
      <tr>
        <th class="col-md-2"></th>
        <th class="col-md-4">Student First Name</th>
        <th class="col-md-4">Student Last Name</th>
        <th>s1</th>
        <th>s2</th>
        <th>s3</th>
        <th>s4</th>
        <th>s5</th>
        <th>s6</th>
      </tr>

      <tr>
        <td>112b443</td>
        <td>me</td>
        <td>test</td>
        <td><input type="text" class="form-control" style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>

      </tr>
      <tr>
        <td>112b443</td>
        <td>me</td>
        <td>test</td>
        <td><input type="text" class="form-control" style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>

      </tr>
      <tr>
        <td>112b443</td>
        <td>me</td>
        <td>test</td>
        <td><input type="text" class="form-control" style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>

      </tr>
      <tr>
        <td>112b443</td>
        <td>me</td>
        <td>test</td>
        <td><input type="text" class="form-control" style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px"></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>
        <td><input type="text" class="form-control"  style="width:40px" ></td>

      </tr>
      </form>
      @endsection
