<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rms_result;
use Illuminate\Support\Facades\DB;

class mastersheetController extends Controller
{
    function getmastersheet1(){
        $result = DB::table('averages')
        ->join('rms_results', 'rms_results.student_id', 'averages.student_id')
        ->join('rms_subjects', 'rms_subjects.id', 'rms_results.subject_id')
        ->get();
        if($result){ 
          return view('master_sheet_1', ['results'=>$result]);
        }
    }
    function getmastersheet2(){
        $result = DB::table('rms_results')
        ->join('rms_students','rms_students.id', 'rms_results.student_id')
        ->join('rms_classes', 'rms_classes.id', 'rms_results.class_id')
        ->join('rms_subjects', 'rms_subjects.id', 'rms_results.subject_id')
        ->join('rms_teachers', 'rms_teachers.id', 'rms_results.teacher_id')
        ->join('averages', 'averages.id', 'rms_results.average_id')
        ->orderBy('coefficient', 'desc')
        ->orderBy('category', 'ASC')
        ->get();
        if($result){ 
          return view('master_sheet_2', ['result'=>$result]);
        }
    }
    function getmastersheet3(){
        $result = DB::table('rms_results')
        ->join('rms_students','rms_students.id', 'rms_results.student_id')
        ->join('rms_classes', 'rms_classes.id', 'rms_results.class_id')
        ->join('rms_subjects', 'rms_subjects.id', 'rms_results.subject_id')
        ->join('rms_teachers', 'rms_teachers.id', 'rms_results.teacher_id')
        ->join('averages', 'averages.id', 'rms_results.average_id')
        ->orderBy('coefficient', 'desc')
        ->orderBy('category', 'ASC')
        ->get();
        if($result){ 
          return view('master_sheet_3', ['result'=>$result]);
        }
    }
}
