# Report-Card-System
report card management system

Collaboration rules

to all collaborators, 

- Fork this repo to your personal account  

to do any modification on the main branch.

- Clone it to you account locally. 
```
git clone https://github.com/andrew21-mch/Rms_version2 
```

- Do your contributions  

- Create a different branch based on the work you do 
```
git checkout -b contrib_branch

``` 

- Push your changes via that branch  
``` 
git add .
git commit -m "commit message" 
git push
```

- Create a pull request to be confirmed from the main branch


- ## Collaborators    
- @andrew21-mch  
