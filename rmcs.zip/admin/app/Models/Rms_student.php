<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rms_student extends Model
{
    public function Rms_student() {
        return $this->HasMany('App\Models\Rms_result');
    }
    use HasFactory;
}
