<?php $__env->startSection('content'); ?>
<div class="class">
  <br><br><br><br>

        <div class="container" style="font-size:12px">
        <center>
          <div class="row col-md-12">
            <table>
              <tr>
                <td colspan="5">
                    <center style="width:230px; float:left">REPUBLIC DU CAMEROUN <br>
                    Paix-Travail-Partrie <br>
                    MINISTRE TO ENSEIGMENT SECONDAIRE <br>
                    DELEGATION REGIONAL DU NORHT WEST  <br>
                    SAINT FRANCISCA MULTILINGUAL <br>
                    EDUCATIONAL COMPLEX</center>
                  </td>

                  <td colspan="2">
                    <center>
                      <span class="iconify" data-icon="icons8:student" data-width="100" data-height="100"></span>
                    </center>
                </td>

                <td colspan="5">

                    <center style="width:230px; float: right">REPUBLIC DU CAMEROUN <br>
                    Paix-Travail-Partrie <br>
                    MINISTRE TO ENSEIGMENT SECONDAIRE <br>
                    DELEGATION REGIONAL DU NORHT WEST  <br>
                    SAINT FRANCISCA MULTILINGUAL <br>
                    EDUCATIONAL COMPLEX</center>
                  </td>

              </div>
              </tr>

            </table>

      </center>
  <table id="customers">
    <div class="row"><h1><center>Class List Form 4</center></h1></div>
      <tr>
        <th>Student First Name</th>
        <th>Student Last Name</th>
        <th>Gender</th>
        <th>DOB</th>
        <th colspan="2">#</th>
      </tr>

      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($user->class_id == 4): ?>
        <tr>
          <td><?php echo e($user->first_name); ?></td>
          <td><?php echo e($user->last_name); ?></td>
          <td><?php echo e($user->gender); ?></td>
          <td><?php echo e($user->date_of_birth); ?></td>
          <td></td>
          <td></td>
        </tr>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.classlistlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u723042533/domains/infocam.blog/public_html/rmcs/admin/resources/views/class/form4.blade.php ENDPATH**/ ?>